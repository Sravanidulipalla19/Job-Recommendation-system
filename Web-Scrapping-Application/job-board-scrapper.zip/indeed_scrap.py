import requests
from bs4 import BeautifulSoup as bs
import json
import boto3
import datetime
import os

REGION = 'us-east-1'
s3 = boto3.resource('s3', region_name = REGION)
# BUCKET_NAME = 'job-recommendation-system-raw-useast-1-69522247-dev'

prefix = "https://www.indeed.com"

KEY_WORD = os.environ['key_word']
EXP_LV = os.environ['experience_level']
JOB_TYPE = os.environ['job_type']
DATE_POSTED = os.environ['date_posted']
NUM_OF_PG = os.environ['number_of_pages']
BUCKET_NAME = os.environ['bucket_name']




def lambda_handler(event, context):
    main()
    

# function that go through every page of inputs
def webpage_to_bs(url, number_of_pages):
    json = []
    for i in range(0, number_of_pages):
        extension = ""
        if i != 0:
            extension = "&start=" + str(i*10)
        url = url + extension
        webpg = requests.get(url)
        try:
            if webpg.status_code == 200:
                print("Parsing {}th page".format(i))
                soup = bs(webpg.text, "html.parser")
                job_lists = soup.find_all("div", {"class": "job_seen_beacon"})
                for job in job_lists:
                    job_info = extract_job_info(job)
                    json.append(job_info)
            else:
                print("Status Code:", webpg.status_code)
                return json
        except Exception as e:
            print(e)
            return json
    return json

# function that extract every required information for each job in a single page
def extract_job_info(job):
    result_content = job.find("td", {"class":"resultContent"})
    a = result_content.find("a")
    hyperlink = a["href"]
    role_name = a.get_text()
    job_id = a["id"]

    company_name = result_content.find("span", {"class": "companyName"})
    company_name = company_name.get_text()
    location = result_content.find("div", {"class": "companyLocation"})
    location = location.get_text()

    salary_estimated = result_content.find("span", {"class": "estimated-salary"})
    if salary_estimated:
        salary_estimated = salary_estimated.get_text()

    job_page = requests.get(prefix + hyperlink)
    job_page = bs(job_page.text, "html.parser")
    job_description = job_page.find("div",{"class":"jobsearch-jobDescriptionText"})
    if job_description:
        job_description = job_description.get_text()
    job_info = {
        "job_id":job_id,
        "company_name":company_name,
        "role": role_name,
        "location":location,
        "salary_estimated": salary_estimated,
        "job_description": job_description,
        "url": prefix+hyperlink,
    }
    return job_info


# main function that execute the scrapping job and store them in json format
def main():
    # key_words = "data"
    # number_of_pages = 10
    # experience_level = "ENTRY_LEVEL"
    # job_type = "fulltime"
    # date_posted = 7
    url = prefix + "/jobs?q=" + KEY_WORD + "&sc=0kf%3Aexplvl%28" + EXP_LV + "%29jt%28" + JOB_TYPE +"%29%3B&fromage=" + str(DATE_POSTED)
    json_data = webpage_to_bs(url, int(NUM_OF_PG))
    
    dt = datetime.datetime.now()
    str_dt = dt.strftime("%Y/%m/%d/%H:%M")
    key = "{}_job_data.json".format(str_dt)
    s3object = s3.Object(BUCKET_NAME, key)

    s3object.put(
        Body=(bytes(json.dumps(json_data).encode('UTF-8')))
    )
